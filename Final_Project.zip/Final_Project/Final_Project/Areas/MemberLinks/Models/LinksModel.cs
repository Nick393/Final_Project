﻿
namespace Final_Project.Areas.MemberLinks.Models

{
    public class LinksModel
    {
        public List<Final_Project.Areas.MemberLinks.Models.DomainModels.Link> links { get; set; } = null!;
        public string type { get; set; }=string.Empty;
    }
}
