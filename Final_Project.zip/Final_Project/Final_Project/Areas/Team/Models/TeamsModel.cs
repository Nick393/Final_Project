﻿
namespace Final_Project.Areas.Team.Models

{
    public class TeamsModel
    {
        public List<Final_Project.Areas.Team.Models.DomainModels.Team> teams { get; set; } = null!;
    }
}
