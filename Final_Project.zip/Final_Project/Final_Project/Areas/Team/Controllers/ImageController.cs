﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Final_Project.Areas.Team.Controllers
{
    public class ImageController : Controller
    {


    }
}
