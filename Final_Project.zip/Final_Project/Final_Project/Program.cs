using Microsoft.EntityFrameworkCore;
using Final_Project.Areas.Student.Models;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Final_Project.Models.DomainModels;
using Final_Project.Models.DataLayer.Configuration;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<Final_Project.Models.SiteContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("SiteContext")));
builder.Services.AddIdentity<Account, IdentityRole>(options => {
    options.Password.RequiredLength = 4;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireDigit = false;
}).AddEntityFrameworkStores<Final_Project.Models.SiteContext>()
  .AddDefaultTokenProviders();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();


app.UseAuthentication();
app.UseAuthorization();

var scopeFactory = app.Services.GetRequiredService<IServiceScopeFactory>();
using (var scope = scopeFactory.CreateScope())
{
    await ConfigureIdentity.CreateAdminUserAsync(scope.ServiceProvider);
}
app.MapAreaControllerRoute(
    name: "mentor",
    areaName: "Mentor",
    pattern: "Mentor/{controller=Home}/{action=Approval}/{id?}"
    );
app.MapAreaControllerRoute(
    name: "student",
    areaName: "Student",
    pattern: "Student/{controller=Home}/{action=Index}/{id?}"
    );
app.MapAreaControllerRoute(
    name: "acctArea",
    areaName: "AcctArea",
    pattern: "Acct/{controller=Acct}/{action=Acct}/{id?}"
    );
app.MapAreaControllerRoute(
    name: "Team",
    areaName: "Team",
    pattern: "Team/{controller=Team}/{action=Index}/{id?}"
    );
app.MapAreaControllerRoute(
    name: "VolunteerRequest",
    areaName: "VolunteerRequest",
    pattern: "VolunteerRequest/{controller=Request}/{action=Request}/{id?}"
    );
app.MapAreaControllerRoute(
    name: "MemberLinks",
    areaName: "MemberLinks",
    pattern: "MemberLinks/{controller=Link}/{action=Links}/{id?}"
    );
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
